<?php
$id = mysqli_connect("localhost:3307","root","","hopital");